package bonus.pizza;

public abstract class Pizza {
	protected String description ="Unknown Pizza";
	protected String name = "Name";
	protected String dough;
	protected String sauce;
	
	public String getDescription() {
		return description;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	void prepare() {
		System.out.println("\nPrepare " + name);
		System.out.println("Tossing dough...");
		System.out.println("Adding toppings: ");
		System.out.println(description);
	}
	
	void bake() {
		System.out.println("Bake for 25 minutes at 350");
	}
	
	protected void cut() {
		System.out.println("Cut the pizza into diagonal slices");
	}
  
	void box() {
		System.out.println("Place pizza in official PizzaStore box");
	}
	
	public abstract double cost();
}

