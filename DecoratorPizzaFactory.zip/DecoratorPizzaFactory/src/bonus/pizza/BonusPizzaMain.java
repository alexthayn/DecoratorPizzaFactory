//Alex Thayn
//This file contains a main driver that test my pizza program
//I used the factory patter and decorator pattern in unison

package bonus.pizza;

import java.text.NumberFormat;

import chicago.ChicagoPizzaStore;
import ny.NYPizzaStore;
import toppings.*;

public class BonusPizzaMain {
	public static void main(String[] args) {
		//Create pizza store factories
		PizzaStore chicagoStore = new ChicagoPizzaStore();
		PizzaStore nyStore = new NYPizzaStore();
		
		//double to money formatter
		NumberFormat formatter = NumberFormat.getCurrencyInstance();
		
		//Order a regular Chicago pizza with triple pepperoni and onions on top
		Pizza pizza = chicagoStore.orderPizza("chicagoPizza");
		//add more toppings
		pizza = new Pepperoni(pizza);
		pizza = new Pepperoni(pizza);
		pizza = new Pepperoni(pizza);
		pizza = new Onions(pizza);
		
		System.out.println("\nAlex ordered a " + pizza.getDescription());
		System.out.println("He paid: " + formatter.format(pizza.cost()) + "\n\n");
		
		//Order a NY style cheese pizza with double pepperoni, extra parmesan cheese, red peppers, black olives, and garlic
		pizza = nyStore.orderPizza("Cheese");
		//add more toppings
		pizza = new Pepperoni(pizza);
		pizza = new Pepperoni(pizza);
		pizza = new ParmesanCheese(pizza);
		pizza = new RedPepper(pizza);
		pizza = new BlackOlives(pizza);
		pizza = new Garlic(pizza);
		
		System.out.println("\nAlex ordered a " + pizza.getDescription());
		System.out.println("He paid: " + formatter.format(pizza.cost()) + "\n\n");
		
		//Order a Chicago style clam pizza with extra eggplant, mozzarella cheese, black olives, and onions
		pizza = chicagoStore.orderPizza("clam");
		//add more toppings
		pizza = new Eggplant(pizza);
		pizza = new MozzarellaCheese(pizza);
		pizza = new BlackOlives(pizza);
		pizza = new Onions(pizza);
		
		System.out.println("\nAlex ordered a " + pizza.getDescription());
		System.out.println("He paid: " + formatter.format(pizza.cost()) + "\n\n");
		
		//Order a NY style veggie pizza with extra red pepper, eggplant, mushroom, onions, black olives, parmesan cheese, and spinach
		pizza = nyStore.orderPizza("veggie");
		//add more toppings
		pizza = new RedPepper(pizza);
		pizza = new Eggplant(pizza);
		pizza = new Mushroom(pizza);
		pizza = new Onions(pizza);
		pizza = new BlackOlives(pizza);
		pizza = new ParmesanCheese(pizza);
		pizza = new Spinach(pizza);
		
		System.out.println("\nAlex ordered a " + pizza.getDescription());
		System.out.println("He paid: " + formatter.format(pizza.cost()) + "\n\n");
	}
}
