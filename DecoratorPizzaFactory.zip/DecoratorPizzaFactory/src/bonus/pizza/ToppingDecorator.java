package bonus.pizza;

public abstract class ToppingDecorator extends Pizza{
	public abstract String getDescription();
}
