//Alex Thayn
//This file contains a main driver to test that the decorator pattern functions correctly

package bonus.pizza;

import chicago.ChicagoPizza;
import toppings.MarinaraSauce;
import toppings.MozzarellaCheese;
import toppings.Onions;
import toppings.Pepperoni;

public class PizzaDecoratorTest {
	public static void main(String[] args) {
		Pizza pizza = new ChicagoPizza();
		
		//Create a chicago style pizza with marinara, mozzarella cheese, pepperoni, and onions
		pizza = new MarinaraSauce(pizza);
		pizza = new MozzarellaCheese(pizza);
		pizza = new Pepperoni(pizza);
		pizza = new Onions(pizza);
		
		System.out.println(pizza.getDescription());
	}
}
