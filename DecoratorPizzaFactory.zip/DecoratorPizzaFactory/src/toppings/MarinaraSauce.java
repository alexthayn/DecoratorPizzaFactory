package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class MarinaraSauce extends ToppingDecorator {
	Pizza pizza;
	
	public MarinaraSauce (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Marinara Sauce";
	}
	
	public double cost() {
		return pizza.cost();
	}
}
