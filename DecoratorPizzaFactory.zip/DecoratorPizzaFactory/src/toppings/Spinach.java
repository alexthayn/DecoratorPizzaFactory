package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Spinach extends ToppingDecorator {
	Pizza pizza;
	
	public Spinach (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Spinach";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}
