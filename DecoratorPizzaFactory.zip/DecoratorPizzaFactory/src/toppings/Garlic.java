package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Garlic extends ToppingDecorator {
	Pizza pizza;
	
	public Garlic (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Garlic";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}