package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class BlackOlives extends ToppingDecorator{
	Pizza pizza;
	
	public BlackOlives (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Black Olives";
	}
	
	public double cost() {
		return .75 + pizza.cost();
	}
}
