package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class RedPepper extends ToppingDecorator {
	Pizza pizza;
	
	public RedPepper (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Red Pepper";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}