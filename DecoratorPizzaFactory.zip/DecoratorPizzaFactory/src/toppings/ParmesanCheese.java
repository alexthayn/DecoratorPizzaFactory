package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class ParmesanCheese extends ToppingDecorator {
	Pizza pizza;
	
	public ParmesanCheese (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Parmesan Cheese";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}
