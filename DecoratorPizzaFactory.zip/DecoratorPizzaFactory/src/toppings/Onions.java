package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Onions extends ToppingDecorator{
	Pizza pizza;
	
	public Onions(Pizza pizza) {
		this.pizza = pizza;
	}
	
	public String getDescription() {
		return pizza.getDescription() + " , Onions";
	}
	
	public double cost() {
		return .50 + pizza.cost();
	}
}