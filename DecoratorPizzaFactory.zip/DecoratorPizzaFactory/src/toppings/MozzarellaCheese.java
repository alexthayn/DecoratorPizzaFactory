package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class MozzarellaCheese extends ToppingDecorator {
	Pizza pizza;
	
	public MozzarellaCheese (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Mozzarella Cheese";
	}
	
	public double cost() {
		return .99 + pizza.cost();
	}
}
