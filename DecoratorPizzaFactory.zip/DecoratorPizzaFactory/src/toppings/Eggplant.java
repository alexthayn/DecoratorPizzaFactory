package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Eggplant extends ToppingDecorator {
	Pizza pizza;
	
	public Eggplant (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Eggplant";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}
