package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Clams extends ToppingDecorator {
	Pizza pizza;
	
	public Clams (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Clams";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}