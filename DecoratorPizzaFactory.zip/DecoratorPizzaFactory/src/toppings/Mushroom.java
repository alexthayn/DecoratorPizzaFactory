package toppings;

import bonus.pizza.Pizza;
import bonus.pizza.ToppingDecorator;

public class Mushroom extends ToppingDecorator {
	Pizza pizza;
	
	public Mushroom (Pizza pizza) {
		this.pizza = pizza;
	}
	public String getDescription() {
		return pizza.getDescription() + ", Mushroom";
	}
	
	public double cost() {
		return .25 + pizza.cost();
	}
}
