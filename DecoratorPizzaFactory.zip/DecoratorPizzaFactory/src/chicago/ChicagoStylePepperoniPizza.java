package chicago;

import bonus.pizza.Pizza;

public class ChicagoStylePepperoniPizza extends Pizza {
	public ChicagoStylePepperoniPizza() {
		name = "Chicago Style Pepperoni Pizza";
		dough = "Extra Thick Crust Dough";
		sauce = "Plum Tomato Sauce";
		description = "Chicago Style Pepperoni Pizza, Mozzarella Cheese, Black Olives, Spinach, Eggplant, Pepperoni";
	}
 
	protected void cut() {
		System.out.println("Cutting the pizza into square slices");
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 12.5;
	}
}
