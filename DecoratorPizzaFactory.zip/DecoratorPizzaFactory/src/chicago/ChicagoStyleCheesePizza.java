package chicago;

import bonus.pizza.Pizza;

public class ChicagoStyleCheesePizza extends Pizza {

	public ChicagoStyleCheesePizza() { 
		name = "Chicago Style Deep Dish Cheese Pizza";
		dough = "Extra Thick Crust Dough";
		sauce = "Plum Tomato Sauce";
		description = "Chicago Style Deep Dish Cheese Pizza";
	}
 
	protected void cut() {
		System.out.println("Cutting the pizza into square slices");
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 12.00;
	}
}
