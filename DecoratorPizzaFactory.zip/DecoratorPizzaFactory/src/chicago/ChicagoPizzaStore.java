package chicago;

import bonus.pizza.Pizza;
import bonus.pizza.PizzaStore;

public class ChicagoPizzaStore extends PizzaStore {

	protected Pizza createPizza(String item) {
		if (item.equalsIgnoreCase("chicagoPizza"))
			return new ChicagoPizza();
		else if (item.equalsIgnoreCase("cheese")) {
        		return new ChicagoStyleCheesePizza();
    	} else if (item.equalsIgnoreCase("veggie")) {
    	    	return new ChicagoStyleVeggiePizza();
    	} else if (item.equalsIgnoreCase("clam")) {
    	    	return new ChicagoStyleClamPizza();
    	} else if (item.equalsIgnoreCase("pepperoni")) {
        		return new ChicagoStylePepperoniPizza();
    	} else return null;
	}
}
