package chicago;

import bonus.pizza.Pizza;

public class ChicagoPizza extends Pizza {
	public ChicagoPizza() {
		description = "Chicago Style Deep Dish Pizza";
		name = "Chicago Style Deep Dish Pizza";
		dough = "Extra Thick Crust Dough";
		sauce = "Plum Tomato Sauce";
	}
	
	public double cost() {
		return 12.00;
	}
}
