package chicago;

import bonus.pizza.Pizza;

public class ChicagoStyleVeggiePizza extends Pizza {
	public ChicagoStyleVeggiePizza() {
		name = "Chicago Deep Dish Veggie Pizza";
		dough = "Extra Thick Crust Dough";
		sauce = "Plum Tomato Sauce";
		description = "Chicago Deep Dish Veggie Pizza, Mozarella Cheese, Black Olives, Spinach, Eggplant";
	}
 
	protected void cut() {
		System.out.println("Cutting the pizza into square slices");
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 12.50;
	}
}
