package chicago;

import bonus.pizza.Pizza;

public class ChicagoStyleClamPizza extends Pizza {
	public ChicagoStyleClamPizza() {
		name = "Chicago Style Clam Pizza";
		dough = "Extra Thick Crust Dough";
		sauce = "Plum Tomato Sauce";
		description = "Chicago Style Clam Pizza, Frozen Clams, Mozzarella Cheese";
	}
 
	protected void cut() {
		System.out.println("Cutting the pizza into square slices");
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 13.00;
	}
}