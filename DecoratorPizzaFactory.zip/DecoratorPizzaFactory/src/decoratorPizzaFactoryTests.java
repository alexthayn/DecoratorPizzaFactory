import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import bonus.pizza.Pizza;
import bonus.pizza.PizzaStore;
import chicago.ChicagoPizzaStore;

import ny.NYPizzaStore;
import toppings.*;

class decoratorPizzaFactoryTests {

	void test() {
		fail("Not yet implemented");
	}
	
	/***************************NY PIZZA TEST*****************************/
	@ParameterizedTest(name="{index}=> pizzaName= {0}, cost= {1}, blackOlives={2}, clams={3}, eggplant= {4}, garlic = {5}, marinaraSauce={6},"
			+ " mozzarellaCheese={7}, mushroom={8}, onions={9}, parmesanCheese={10}, pepperoni={11}, redPepper={12}, spinach={13}")
	@CsvSource({
		"cheese, 12,2,0,0,0,0,0,0,0,0,0,0,0",
		"pepperoni, 13,2,0,0,0,0,0,0,0,0,0,0,0",
		"veggie, 28.41,5,2,0,5,5,9,8,2,0,0,0,0,0",
		"clam, 15,2,0,0,0,0,0,3,0,2,0,0,1",
		"nypizza, 92.72,2,0,100,12,12,3,1,0,30,05,70,90",
		
	})
	void parameterizedNYPizza(String pizzaName, double cost, int blackOlives, int clams, int eggplant, int garlic, int marinaraSauce,
			int mozzarellaCheese, int mushroom, int onions, int parmesanCheese, int pepperoni, int redPepper, int spinach)
	{
		PizzaStore nyStore = new NYPizzaStore();
		Pizza pizza = nyStore.orderPizza(pizzaName);
		
		for(int i=0;i<blackOlives;i++)
			pizza = new BlackOlives(pizza);
		for(int i=0;i<clams;i++)
			pizza = new Clams(pizza);
		for(int i=0;i<eggplant;i++)
			pizza = new Eggplant(pizza);
		for(int i=0;i<garlic;i++)
			pizza = new Garlic(pizza);
		for(int i=0;i<marinaraSauce;i++)
			pizza = new MarinaraSauce(pizza);
		for(int i=0;i<mozzarellaCheese;i++)
			pizza = new MozzarellaCheese(pizza);
		for(int i=0;i<mushroom;i++)
			pizza = new Mushroom(pizza);
		for(int i=0;i<onions;i++)
			pizza = new Onions(pizza);
		for(int i=0;i<parmesanCheese;i++)
			pizza = new ParmesanCheese(pizza);
		for(int i=0;i<pepperoni;i++)
			pizza = new Pepperoni(pizza);
		for(int i=0;i<redPepper;i++)
			pizza = new RedPepper(pizza);
		for(int i=0;i<spinach;i++)
			pizza = new Spinach(pizza);		
		
		assertEquals(cost, pizza.cost(), .00001);
	}
	
	/***************************Chicago PIZZA TEST*****************************/
	@ParameterizedTest(name="{index}=> pizzaName= {0}, cost= {1}, blackOlives={2}, clams={3}, eggplant= {4}, garlic = {5}, marinaraSauce={6},"
			+ " mozzarellaCheese={7}, mushroom={8}, onions={9}, parmesanCheese={10}, pepperoni={11}, redPepper={12}, spinach={13}")
	@CsvSource({
		"cheese, 13.5,2,0,0,0,0,0,0,0,0,0,0,0",
		"pepperoni, 14,2,0,0,0,0,0,0,0,0,0,0,0",
		"veggie, 29.91,5,2,0,5,5,9,8,2,0,0,0,0,0",
		"clam, 16,2,0,0,0,0,0,3,0,2,0,0,1",
		"chicagopizza, 94.72,2,0,100,12,12,3,1,0,30,05,70,90",
		
	})
	void parameterizedChicagoPizza(String pizzaName, double cost, int blackOlives, int clams, int eggplant, int garlic, int marinaraSauce,
			int mozzarellaCheese, int mushroom, int onions, int parmesanCheese, int pepperoni, int redPepper, int spinach)
	{
		PizzaStore chicagoStore = new ChicagoPizzaStore();
		Pizza pizza = chicagoStore.orderPizza(pizzaName);
		
		for(int i=0;i<blackOlives;i++)
			pizza = new BlackOlives(pizza);
		for(int i=0;i<clams;i++)
			pizza = new Clams(pizza);
		for(int i=0;i<eggplant;i++)
			pizza = new Eggplant(pizza);
		for(int i=0;i<garlic;i++)
			pizza = new Garlic(pizza);
		for(int i=0;i<marinaraSauce;i++)
			pizza = new MarinaraSauce(pizza);
		for(int i=0;i<mozzarellaCheese;i++)
			pizza = new MozzarellaCheese(pizza);
		for(int i=0;i<mushroom;i++)
			pizza = new Mushroom(pizza);
		for(int i=0;i<onions;i++)
			pizza = new Onions(pizza);
		for(int i=0;i<parmesanCheese;i++)
			pizza = new ParmesanCheese(pizza);
		for(int i=0;i<pepperoni;i++)
			pizza = new Pepperoni(pizza);
		for(int i=0;i<redPepper;i++)
			pizza = new RedPepper(pizza);
		for(int i=0;i<spinach;i++)
			pizza = new Spinach(pizza);		
		
		assertEquals(cost, pizza.cost(), .00001);
	}

}

