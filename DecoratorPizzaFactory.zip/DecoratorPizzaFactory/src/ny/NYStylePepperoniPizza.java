package ny;

import bonus.pizza.Pizza;

public class NYStylePepperoniPizza extends Pizza {

	public NYStylePepperoniPizza() {
		name = "NY Style Pepperoni Pizza";
		dough = "Thin Crust Dough";
		sauce = "Marinara Sauce";
		description = "NY Style Pepperoni Pizza, Reggian Cheese, Pepperoni, Garlic, Onion, Mushrooms, Red Pepper";
	}
	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 11.5;
	}

}
