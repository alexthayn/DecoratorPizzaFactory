package ny;

import bonus.pizza.Pizza;
import bonus.pizza.PizzaStore;

public class NYPizzaStore extends PizzaStore {

	protected Pizza createPizza(String item) {
		if (item.equalsIgnoreCase("nyPizza"))
			return new NYPizza();
		else if (item.equalsIgnoreCase("cheese")) {
			return new NYStyleCheesePizza();
		} else if (item.equalsIgnoreCase("veggie")) {
			return new NYStyleVeggiePizza();
		} else if (item.equalsIgnoreCase("clam")) {
			return new NYStyleClamPizza();
		} else if (item.equalsIgnoreCase("pepperoni")) {
			return new NYStylePepperoniPizza();
		} else return null;
	}
}

