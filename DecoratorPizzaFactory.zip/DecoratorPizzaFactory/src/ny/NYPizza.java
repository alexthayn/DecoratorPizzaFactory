package ny;

import bonus.pizza.Pizza;

public class NYPizza extends Pizza{
	public NYPizza() {
		name = "NY Style Pizza";
		description = "NY Style Pizza";
		dough = "Thin Crust Dough";
		sauce = "Marinara Sauce";
	}
	
	public double cost() {
		return 10.00;
	}
}
