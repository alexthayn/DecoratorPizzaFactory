package ny;

import bonus.pizza.Pizza;

public class NYStyleCheesePizza extends Pizza {

	public NYStyleCheesePizza() { 
		name = "NY Style Sauce and Cheese Pizza";
		dough = "Thin Crust Dough";
		sauce = "Marinara Sauce";
		description = "NY Style Sauce and Cheese Pizza, Reggiano Cheese";
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 10.5;
	}
}
