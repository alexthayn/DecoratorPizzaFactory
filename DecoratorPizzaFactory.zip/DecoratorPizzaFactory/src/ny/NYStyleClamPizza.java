package ny;

import bonus.pizza.Pizza;

public class NYStyleClamPizza extends Pizza {

	public NYStyleClamPizza() {
		name = "NY Style Clam Pizza";
		dough = "Thin Crust Dough";
		sauce = "Marinara Sauce";
		description = "NY Style Clam Pizza, Reggiano Cheese, Fresh Clams";
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 12.0;
	}
}
