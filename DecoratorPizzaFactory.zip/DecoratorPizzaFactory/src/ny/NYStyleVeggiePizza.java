package ny;

import bonus.pizza.Pizza;

public class NYStyleVeggiePizza extends Pizza {

	public NYStyleVeggiePizza() {
		name = "NY Style Veggie Pizza";
		dough = "Thin Crust Dough";
		sauce = "Marinara Sauce";
		description = "NY Style Veggie Pizza, Reggiano Cheese, Garlic, Onion, Mushrooms, Red Pepper";
	}

	@Override
	public double cost() {
		// TODO Auto-generated method stub
		return 11.0;
	}
}
