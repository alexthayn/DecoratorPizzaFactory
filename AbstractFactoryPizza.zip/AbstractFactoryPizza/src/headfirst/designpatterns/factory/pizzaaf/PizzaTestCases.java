package headfirst.designpatterns.factory.pizzaaf;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PizzaTestCases {

	void test() {
		fail("Not yet implemented");
	}
	
	@ParameterizedTest(name="{index}=> pizzaType= {0}, cost= {1}")
	@CsvSource({
		"cheese, 11.50",
		"veggie, 11.99",
		"clam, 13.50",
		"pepperoni, 11.99"
	})
	void chicagoPizzaTest(String pizzaType, double cost)
	{
		PizzaStore chicagoStore = new ChicagoPizzaStore();
		
		Pizza pizza = chicagoStore.orderPizza(pizzaType);
		
		assertEquals(cost, pizza.cost,.00001);
	}

	@ParameterizedTest(name="{index}=> pizzaType= {0}, cost= {1}")
	@CsvSource({
		"cheese, 10.50",
		"veggie, 12.99",
		"clam, 12.50",
		"pepperoni, 10.99"
	})
	void NYPizzaTest(String pizzaType, double cost)
	{
		PizzaStore nyStore = new NYPizzaStore();
		
		Pizza pizza = nyStore.orderPizza(pizzaType);
		
		assertEquals(cost, pizza.cost,.00001);
	}
}
