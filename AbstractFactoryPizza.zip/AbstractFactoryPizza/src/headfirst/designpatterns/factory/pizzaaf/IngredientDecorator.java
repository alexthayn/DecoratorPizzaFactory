package headfirst.designpatterns.factory.pizzaaf;

public abstract class IngredientDecorator {
	
	public abstract class CondimentDecorator extends Pizza {
		public abstract String getDescription();
	}
}
